#!/bin/bash

sudo certbot -n -d ${DOMAIN} --nginx --agree-tos --email ${EMAIL} &&

echo "0 0,12 * * * root /opt/certbot/bin/python -c 'import random; import time; time.sleep(random.random() * 3600)' && sudo certbot renew -q" | sudo tee -a /etc/crontab > /dev/null